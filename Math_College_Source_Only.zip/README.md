# Math Collège — connected MVP

This project is preconfigured with the Supabase Project URL and the publishable key supplied by the project owner.

## Run
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## Supabase
- `.env.local` contains the project URL and publishable key.
- Never put a Supabase secret/service-role key in browser code.
- Authentication uses Supabase Auth.
- New registrations are assigned `student` by the database trigger.
- Admin/teacher role changes must be done by a trusted administrator.
- Content reads only published records. Staff can add content after sign-in.

## Current scope
- French/Arabic interface toggle
- 1AC / 2AC / 3AC levels
- Supabase email/password sign-in and student sign-up
- Profile role lookup
- Published content listing
- Admin/teacher content creation
- Database connection indicator

The quiz player, automatic grading, detailed progress reports, and Android packaging are planned next.
